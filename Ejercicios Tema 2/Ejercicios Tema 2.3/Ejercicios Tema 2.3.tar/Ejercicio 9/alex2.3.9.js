let numero = parseFloat(prompt("Introduzca un número"));
if(numero%2==0) alert("Es par");
else alert("Es impar");