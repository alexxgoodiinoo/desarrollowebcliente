let nombre = prompt("Dime tu nombre");
let apellido = prompt("Dime tu apellido");
console.log("Hola " + nombre + " " + apellido);