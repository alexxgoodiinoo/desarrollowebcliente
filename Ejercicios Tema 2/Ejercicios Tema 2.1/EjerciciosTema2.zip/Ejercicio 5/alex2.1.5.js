let texto = prompt("Introduzca un texto");
let tamanio = texto.length;
alert("El largo del texto ingresado es: " + tamanio); 