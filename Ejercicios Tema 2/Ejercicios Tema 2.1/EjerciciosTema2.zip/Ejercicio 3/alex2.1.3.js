let numero1 = parseFloat(prompt("Dime el valor del primer número"));
let numero2 = parseFloat(prompt("Dime el valor del segundo número")), resultado;
resultado = numero1 + numero2;
alert("El resultado es: " + resultado);