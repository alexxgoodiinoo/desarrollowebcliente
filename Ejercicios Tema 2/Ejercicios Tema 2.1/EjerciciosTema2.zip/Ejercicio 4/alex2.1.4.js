let numero = parseFloat(prompt("Introduzca un número"));
let numerotriple = parseFloat(numero * 3);
console.log("El triple de " + numero + " es: " + numerotriple);