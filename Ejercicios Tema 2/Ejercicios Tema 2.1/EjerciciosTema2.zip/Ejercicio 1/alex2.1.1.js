let nombre = "Alex";
let apellido = "Godino";
console.log("Hola, me llamo " + nombre + " " + apellido);