//Apartado 1
let cadena1 = "Hola";
let cadena2 = "Hola";
console.log(cadena1==cadena2);

//Apartado 2
let cadena3 = "Hola";
let cadena4 = "Hellou";
console.log(cadena3==cadena4);

//Apartado 3
let cadena5 = 5;
let cadena6 = "5";
console.log(cadena5===cadena6);

//Apartado 4
let cadena7 = 5;
let cadena8 = "5";
console.log(cadena7==cadena8);