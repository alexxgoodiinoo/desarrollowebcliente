function calculoMayor(num1, num2){
    if(num1==num2) alert("Ambos números son iguales");
    else alert("El número mayor es : " + Math.max(num1, num2));
}

calculoMayor(4,4);