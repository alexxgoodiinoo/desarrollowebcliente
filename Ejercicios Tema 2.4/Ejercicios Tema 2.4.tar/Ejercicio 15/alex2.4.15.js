function saludo(){
    alert("Hola, bienvenido");
}

saludo();