function iterarArray(array){
    array.forEach(elementoArray => {
        console.log(elementoArray);
    });
}

iterarArray([[2,5,2,4],[5,2,1,5]]);