let ensaladaDeFrutas = ["manzana", "pera", "melocotón", "plátano", "kiwi", "granada", "aguacate"];

console.log("Las frutas que hay en la ensalada son:");
for (let i = 0; i < ensaladaDeFrutas.length; i++) {
    console.log(ensaladaDeFrutas[i]);
}