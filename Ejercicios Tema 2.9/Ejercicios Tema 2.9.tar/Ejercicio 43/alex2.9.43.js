let setNumeros = new Set([100,200,300]);
setNumeros.delete(200);
console.log(setNumeros);