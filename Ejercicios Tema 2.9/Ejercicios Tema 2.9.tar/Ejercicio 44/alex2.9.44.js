let setNumeros = new Set([5,10,15,20]);
console.log(setNumeros.size);