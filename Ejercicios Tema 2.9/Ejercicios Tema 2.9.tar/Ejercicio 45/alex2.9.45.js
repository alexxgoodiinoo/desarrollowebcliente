let setNumeros = new Set([1,2,3,4,5]);
let arrayNumeros = [...setNumeros];
arrayNumeros.push(6);
console.log(arrayNumeros);