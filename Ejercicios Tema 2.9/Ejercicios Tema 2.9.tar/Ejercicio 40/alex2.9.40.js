let arrayNumeros = [1,2,2,3,4,4,5];
let numerosNoDuplicados = new Set(arrayNumeros);
console.log(numerosNoDuplicados);