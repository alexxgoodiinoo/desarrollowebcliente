let setNumeros = new Set();
setNumeros.add(1);
setNumeros.add(6);
setNumeros.add(4);
setNumeros.add(15);
setNumeros.add(12);
console.log(setNumeros);