let setNumeros = new Set([10,20,30]);
if(setNumeros.has(20)) alert("El número si existe en el set");
console.log(setNumeros);