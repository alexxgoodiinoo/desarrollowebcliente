let persona = {
    nombre: "Alex",
    edad: 20,
    ciudad: "Torredonjimeno"
}

for (let datos in persona) {
    console.log(persona[datos]);
}