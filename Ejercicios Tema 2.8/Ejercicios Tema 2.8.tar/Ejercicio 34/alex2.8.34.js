let empresa = {
    nombre: "Petroprix",
    ubicacion: "Martos",
    empleados: {
        nombre: "Alex",
        puesto: "Jefe",
        salario: 1500
    }
}

console.log(empresa.empleados.nombre);
console.log(empresa.empleados.puesto);
console.log(empresa.empleados.salario);