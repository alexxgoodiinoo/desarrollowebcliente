let mapPersonas = new Map();

mapPersonas.set("nombre", "Alex");
mapPersonas.set("edad", 20);
mapPersonas.set("profesion", "desarrollador");

let arrayMap = [...mapPersonas];

console.log(arrayMap);