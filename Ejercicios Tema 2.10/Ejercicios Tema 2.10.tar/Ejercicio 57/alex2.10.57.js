let map1 = new Map();

map1.set("producto", "portatil");
map1.set("precio", 1000);
map1.set("cantidad", 2);

for (let element of map1) {
    console.log(element);
}