let map1 = new Map();

map1.set("producto", "portatil");
map1.set("precio", 1000);
map1.set("cantidad", 2);

console.log(map1.size);