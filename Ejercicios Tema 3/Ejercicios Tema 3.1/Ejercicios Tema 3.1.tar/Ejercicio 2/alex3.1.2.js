let producto = {
    nombre: "Laptop",
    precio: 1200,
    stock: 10
}

let productos = JSON.stringify(producto);
console.log(productos);