function cambiarFondo(){
    const body = document.body;
    body.style.backgroundColor = "magenta";
}
