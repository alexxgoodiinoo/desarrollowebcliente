let frase = document.getElementById("paragraph");

frase.innerHTML = location.href;