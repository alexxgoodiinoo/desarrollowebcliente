function mostrarAlerta(){
    const ancho = window.innerWidth;
    const alto = window.innerHeight;
    alert("Ancho: " + ancho + "\nAlto: " + alto);
}