document.getElementById('moveWindowButton')
    .addEventListener('click', function() { 
        window.moveBy(100, 100); 
    });